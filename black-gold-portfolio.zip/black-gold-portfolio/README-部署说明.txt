黑金高级风个人作品网站 - 中文说明
==================================

一、压缩包内容
- index.html：网站页面内容
- style.css：黑金风格、布局和手机适配
- script.js：手机导航、回到顶部、自动年份
- assets/：可放你自己的图片（当前页面使用 CSS 装饰图形，不依赖本地图片）

二、如何在电脑上预览
1. 解压 ZIP 文件。
2. 双击打开 index.html。
3. 浏览器会显示网站。此时不需要安装任何软件。

三、发布到 GitHub Pages（免费）
第 1 步：注册 GitHub
1. 打开 https://github.com/
2. 点击 Sign up（注册）。
3. 输入邮箱、设置密码、选择用户名，并按页面提示完成邮箱验证。
4. 请记住用户名；不要把密码告诉任何人。

第 2 步：创建仓库
1. 登录 GitHub。
2. 点击右上角 +，选择 New repository。
3. Repository name（仓库名称）输入：my-portfolio
4. 选择 Public（公开）。
5. 可以勾选 Add a README file，也可以不勾选。
6. 点击 Create repository。

第 3 步：上传网站文件
1. 进入新建的 my-portfolio 仓库。
2. 点击 Add file → Upload files。
3. 将 index.html、style.css、script.js 和 README-部署说明.txt 拖入上传区域。
   注意：上传的是这些文件本身，不是 ZIP 压缩包。
4. 在页面下方点击 Commit changes。
5. 上传后确认仓库首页能直接看到 index.html 和 style.css。

第 4 步：开启 GitHub Pages
1. 在仓库中点击 Settings。
2. 左侧找到 Pages。
3. 在 Build and deployment（构建与部署）下：
   - Source 选择 Deploy from a branch
   - Branch 选择 main
   - 文件夹选择 /(root)
4. 点击 Save。
5. 等待几分钟，再回到 Settings → Pages 查看发布网址。
   通常网址类似：
   https://你的GitHub用户名.github.io/my-portfolio/
   其中“你的GitHub用户名”要替换成你自己的用户名。

四、修改个人信息
1. 在仓库首页点击 index.html。
2. 点击铅笔图标（Edit this file）。
3. 搜索并修改以下示例文字：
   - 你的名字
   - 作品标题和作品介绍
   - 兴趣爱好
   - 所在地、身份、目前关注、座右铭
   - hello@example.com（示例邮箱）
4. 修改完后点击 Commit changes。
5. 等待网站更新后刷新网址即可。

提示：若要替换头像或展示自己的图片，可以把图片上传到仓库，并进一步修改 index.html。不要上传身份证、住址、密码等敏感信息。

五、常见问题
- 网站显示 404：检查仓库是否为 Public、Pages 是否选择 main 和 /(root)，并确认 index.html 位于仓库根目录。
- 刚开启时打不开：等 2–10 分钟后再试。
- 页面没有样式：确认 style.css 与 index.html 位于同一目录，文件名大小写完全一致。
- 这是纯静态网站，不支持 PHP、数据库或服务器端表单。邮件按钮会打开访客设备上的邮件应用。

六、重要
GitHub 页面按钮文字可能因语言或界面更新略有差异。请勿把 GitHub 密码、验证码或恢复代码发给别人。
