const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
    menuButton.textContent = isOpen ? '×' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.textContent = '☰';
    });
  });
}

const backTop = document.querySelector('.back-top');
window.addEventListener('scroll', () => {
  if (backTop) backTop.classList.toggle('visible', window.scrollY > 450);
});
if (backTop) backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const year = document.querySelector('#year');
if (year) year.textContent = new Date().getFullYear();

/*
 * 快速个性化：
 * 1. 打开 index.html，搜索“你的名字”，替换为你的昵称。
 * 2. 搜索示例邮箱 hello@example.com，替换成你自己的邮箱。
 * 3. 修改作品标题、介绍和兴趣卡片文字。
 */
